<header>
    <h1>BLOG VERDE</h1>
    <hr>
</header>