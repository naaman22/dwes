

<footer>
        <p><strong>Creado por: Naaman Lopez Valera</strong></p>
        <p>Examen: Desarrollo web entorno servidor</p>
        <p><?php echo $_SESSION["Y"]; ?></p>
</footer>