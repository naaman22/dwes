<?php
header ("Location: formulario1.php");
die;
?>