<?php
  session_start();

  if(isset($_SESSION["img"])){
    header("location: historieta.php");
  }
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Historieta</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
    <div>
     
    <form action="historieta.php">
        <button class="inicio" type="submit">
        Comenzar historieta
        </button>
    <form>
    <div>
</body>
</html>
